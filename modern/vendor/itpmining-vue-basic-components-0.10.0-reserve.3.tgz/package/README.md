# Vue Component Library by ITP Mining.

## Development (Git flow)

![image](https://github.com/user-attachments/assets/e2d967e6-b64b-49ae-a39e-a3fbbd7d480b)

We currently use [Gitflow](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow). Any features to the repository should be started as branches coming off the **Develop** branch and be prefixed with `feature/` (or an appropriate semantic prefix for commits that don't technically constitute a true 'feature', e.g. 'refactor/[refactor-description]' etc...). Any patches for production should be applied directly to **Main** AND **Develop** and be prefixed with `hotfix/`. All branches should be associated with a pull request for merging back into **Develop** or **Main** branches. For non-trivial commits (or in general), having someone else approve your pull request is preferred.

### Workflow for new feature branch
- Start on Develop branch (`git checkout develop`)
- Pull recent changes (`git pull`)
- Create new branch (`git checkout -b feature/[feature-name]`)
- Add changes (`git status` to see changes, `git add .` to add all changes)
- Commit changes (`git commit -m 'commit message'`)
- [Rebase if necessary: see note below]
- Push to Github (`git push origin feature/[feature-name]`)

Once the local feature branch is pushed up to Github, initate a pull request to have it included into the main **Dev** branch. As a general rule, you should not accept your own pull request.

#### Rebasing in a feature branch

Should other contributors commit changes to `develop` while a feature branch is under development, a **Rebase** is required for a clean project merge. For a description of rebasing please see the [docs](https://git-scm.com/docs/git-rebase). For a description of rebasing vs. plain old merging see this [blog post](https://medium.com/@justintulk/git-rebase-vs-git-merge-for-beginners-aecc1ef1c718#.g89chz4h2). In short, _rebasing_ ensures that your changes are applied on top of changes merged into `develop` by other feature branches completed since the feature branch in question was split off. It isolates conflict resolution to the feature branches and keeps merge conflict resolution commits from polluting the primary `develop` branch history.

To do a rebase, after your last commit into `feature/[feature-description]` please follow the following process:

- checkout develop `git checkout develop`
- refresh develop branch to latest `git pull`
- re-checkout feature branch `git checkout feature/[feature-description]`
- apply rebase `git rebase develop` **NOTE** - rebase must happen from WITHIN your feature branch
- resolve any merge conflicts appropriately 
- push rebased feature branch to remote (see above)

### Workflow for hotfix applied directly to **Main**
- Start on Main branch (`git checkout main`)
- Force pull Main (`git pull -f`)
- Create new hotfix branch (`git checkout -b hotfix/[hotfix-name]`)
- Add changes (`git status` to see changes, `git add .` to add all changes)
- Commit changes (`git commit -m 'commit message'`)
- Push to Github (`git push origin hotfix/[hotfix-name]`)

Once the local hotfix branch is pushed up to Github, initate a pull request to have it included into the main **Main** branch. As a general rule, you should not accept your own pull request. Once approved, merge **hotfix/[hotfix-name]** into **Develop** as well as **Main**.

*Text taken [from Gist](https://gist.github.com/jtulk/89004ac8c4c19c8ff461a4b7f6b9789a) by @jtulk.*

### Workflow for releases
- Start on Develop branch (`git checkout develop`)
- Pull recent changes (`git pull`)
- Create new release branch (`git checkout -b release/[version]`)
- Add changes (`git status` to see changes, `git add .` to add all changes)
- Commit changes (`git commit -m 'commit message'`)
- [Rebase if necessary: see note below]
- Push to Github (`git push origin feature/[feature-name]`)

#### Release versioning

We follow [semantic versioning](https://github.com/semver/semver?tab=readme-ov-file) when making releases (e.g. `1.0.2`), each part of the version denoting the `MAJOR`, `MINOR` and `PATCH` release changes respectively.

At the moment of development, the initial release is set as version **0.1.0**. Each new feature release increments the `MINOR` version, whereas hotfix releases increment the `PATCH` part of the current version.

## Storybook + Chromtaic

*@TODO figure out the design processes.*

## Actions 

### Releases

On each release, the package is automatically published to the Github NPM repository. In order, to add this package to project, one needs to:
- Generate a new Github personal access token (classic), [see](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-personal-access-token-classic)
  - Select the appropriate expiration time for your token (preferrably, not more than 90 days). *Note: do not forget to update your token once expired!*
  - Select the scopes you'd like to grant this token.
    - `repo`
    - `write:packages`
    - `read:packages`
- Add the following line to your `~/.npmrc` file:
  - `//npm.pkg.github.com/:_authToken={{YOUR_TOKEN}}`
- Create `.npmrc` file in the project root and define the registry scope:
  - `@itpmining:registry=https://npm.pkg.github.com/`

By now, you should be ready to go! Install with `npm install @itpmining/vue-basic-components`


### Chromatic

*@TODO figure out the design review processes.*

# Vue 3 + Vite

This template should help get you started developing with Vue 3 in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

## Recommended IDE Setup

- [VS Code](https://code.visualstudio.com/) + [Vue - Official](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (previously Volar) and disable Vetur

## ITP shared application components

New reusable AppShell, AppTopbar, AppSidebar, PageHeader, AccountMenu, switchers,
Card, Drawer, DataTable, FilterToolbar, ConfirmDialog and design tokens are documented in
[docs/SHARED_UI_FOUNDATIONS_20261106.md](docs/SHARED_UI_FOUNDATIONS_20261106.md).

Run `npm run build-storybook` to review components. On the reserve preview server,
the local-only test catalog uses http://127.0.0.1:6007; do not expose it publicly.

See also [Select and component backlog](docs/SELECT_AND_COMPONENT_BACKLOG_20261106.md) for the compatibility matrix.
